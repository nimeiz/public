#include "stdafx.h"
#include "AutoTag.h"
#include "listview.h"


EE_Context* g_pContext=NULL;
int g_nMenuCmd=0;
bool g_bEnable=true;

struct AutoGroup
{
	HWND hWndDoc;
	AutoGroup(HWND h){
		hWndDoc=h;
		::SendMessage(hWndDoc, ECM_GROUPUNDO, TRUE, 0);
	}
	~AutoGroup(){
		::SendMessage(hWndDoc, ECM_GROUPUNDO, FALSE, 0);
	}
};

void SaveConfig()
{
	TCHAR szBuf[_MAX_PATH+1];
	::GetModuleFileName(g_pContext->hModule, szBuf, _MAX_PATH );
	LPCTSTR lpstrFileName=PathFindFileName(szBuf);
	if( !lpstrFileName )
		return;
	TCHAR szIni[_MAX_PATH+20];
	StringCchPrintf(szIni, _MAX_PATH+20, _T("%.*ssetting.ini"), lpstrFileName-szBuf, szBuf);
	::WritePrivateProfileString( _T("AutoTag"), _T("Enable"), g_bEnable?_T("1"):_T("0"), szIni );
}

void GetConfig()
{
	TCHAR szBuf[_MAX_PATH+1];
	::GetModuleFileName(NULL, szBuf, _MAX_PATH );
	LPCTSTR lpstrFileName=PathFindFileName(szBuf);
	if( !lpstrFileName )
		return;
	TCHAR szIni[_MAX_PATH+20];
	StringCchPrintf(szIni, _MAX_PATH+20, _T("%.*ssetting.ini"), lpstrFileName-szBuf, szBuf);

	TCHAR szRet[8];
	::GetPrivateProfileString( _T("AutoTag"), _T("Enable"), _T("1"), szRet, 8, szIni );
	g_bEnable=(szRet[0]=='1');
}

bool IsTagWord(TCHAR ch)
{
	if( ch=='-' || ch=='_' || ::_istalnum(ch) )
		return true;
	return false;
}

int OnInputChar(HWND hWndDoc, wchar_t* text, int length)
{
	if(!g_bEnable)
		return 0;

	TCHAR ch=text[0];
	if( ch=='/' ){
		EC_Pos pos={0,0};
		::SendMessage(hWndDoc, ECM_GETCARETPOS, (WPARAM)&pos, 0);
		if( !pos.col )
			return 0;

		TCHAR chPrev=::SendMessage(hWndDoc, ECM_GETCHAR, pos.line, pos.col-1);
		if( chPrev=='<' ){
			TCHAR chNext=::SendMessage(hWndDoc, ECM_GETCHAR, pos.line, pos.col+1);
			if( !IsTagWord(chNext) ){
				LPCTSTR lpstrScope=(LPCTSTR)::SendMessage(hWndDoc, ECM_GETSCOPE, (WPARAM)&pos, 0);
				if( lpstrScope && (!_tcsicmp(lpstrScope, L"source.html") || !_tcsicmp(lpstrScope, L"source.xml")) ){
					TCHAR str[]={ch, 0};
					EC_InsertText eci={str, 1};
					::SendMessage(hWndDoc, ECM_INSERTTEXT, (WPARAM)&pos, (LPARAM)&eci);

					LPCTSTR lpstrRet=(LPCTSTR)::SendMessage(hWndDoc, ECM_CLOSETAG, 0, 0);
					if( lpstrRet )
						return EEHOOK_RET_DONTROUTE;
				}
			}
		}
	}
	else if( ch=='>' ){
		EC_Pos pos={0,0};
		::SendMessage(hWndDoc, ECM_GETCARETPOS, (WPARAM)&pos, 0);

		if( !pos.col )
			return 0;

		TCHAR chPrev=::SendMessage(hWndDoc, ECM_GETCHAR, pos.line, pos.col-1);
		if( chPrev=='/' || !IsTagWord(chPrev) )
			return 0;

		TCHAR chNext=::SendMessage(hWndDoc, ECM_GETCHAR, pos.line, pos.col+1);
		if( !IsTagWord(chNext) ){
			LPCTSTR lpstrScope=(LPCTSTR)::SendMessage(hWndDoc, ECM_GETSCOPE, (WPARAM)&pos, 0);
			if( lpstrScope && (!_tcsicmp(lpstrScope, L"source.html") || !_tcsicmp(lpstrScope, L"source.xml")) ){
				TCHAR str[]={ch, 0};
				EC_InsertText eci={str, 1};
				::SendMessage(hWndDoc, ECM_INSERTTEXT, (WPARAM)&pos, (LPARAM)&eci);

				LPCTSTR lpstrRet=(LPCTSTR)::SendMessage(hWndDoc, ECM_CLOSETAG, 0, 0);
				if( lpstrRet )
					return EEHOOK_RET_DONTROUTE;
			}
		}
	}

	return 0;
}

int OnAppMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if( uMsg!=WM_COMMAND  )
		return 0;
	int cmd=(int)LOWORD(wParam);
	if( cmd==g_nMenuCmd ){
		g_bEnable=!g_bEnable;
		SaveConfig();
		return EEHOOK_RET_DONTROUTE;
	}
	return 0;
}

int OnAppIdle(HWND hWnd, HWND hChildFrame)
{
	EE_UpdateUIElement eeu={EE_UI_SETCHECK, g_bEnable};
	::SendMessage(g_pContext->hMain, EEM_UPDATEUIELEMENT, g_nMenuCmd, (LPARAM)&eeu);
	return 0;
}

int OnListPluginCommand(HWND hWnd)
{
	int cnt=(int)::SendMessage(hWnd, LVM_GETITEMCOUNT, 0, 0L);
	InsertItem(hWnd, cnt, L"");
	SetItemText(hWnd, cnt, 1, L"pl_autotag");
	SetItemText(hWnd, cnt, 2, L"Toggle Auto Tag");

	return 0;
}

int OnExecutePluginCommand(const wchar_t* command)
{
	if( !_tcsicmp(command, L"pl_autotag") ){
		g_bEnable=!g_bEnable;
		SaveConfig();
		return EEHOOK_RET_DONTROUTE;
	}
	return 0;
}

int OnMenuSelect(int id, wchar_t* text, int length)
{
	if( id==g_nMenuCmd ){
		lstrcpy(text, L"Enable or disable HTML/XML tag complete");
		return EEHOOK_RET_DONTROUTE;
	}
	return 0;
}

DWORD EE_PluginInit(EE_Context* pContext)
{
	g_pContext=pContext;

	//hook function
	::SendMessage(g_pContext->hMain, EEM_SETHOOK, EEHOOK_TEXTCHAR, (LPARAM)OnInputChar);
	::SendMessage(g_pContext->hMain, EEM_SETHOOK, EEHOOK_APPMSG, (LPARAM)OnAppMessage);
	::SendMessage(g_pContext->hMain, EEM_SETHOOK, EEHOOK_APPIDLE, (LPARAM)OnAppIdle);
	::SendMessage(g_pContext->hMain, EEM_SETHOOK, EEHOOK_EXECUTEPLUGINCOMMAND, (LPARAM)OnExecutePluginCommand);
	::SendMessage(g_pContext->hMain, EEM_SETHOOK, EEHOOK_LISTPLUGINCOMMAND, (LPARAM)OnListPluginCommand);
	::SendMessage(g_pContext->hMain, EEM_SETHOOK, EEHOOK_MENUSELECT, (LPARAM)OnMenuSelect);

	//UI element
	g_nMenuCmd=++(*g_pContext->pCommand);
	::AppendMenu(g_pContext->hPluginMenu, MF_STRING, g_nMenuCmd, L"Auto Tag");

	EE_UpdateUIElement eeu={EE_UI_ADD, 0};
	::SendMessage(g_pContext->hMain, EEM_UPDATEUIELEMENT, g_nMenuCmd, (LPARAM)&eeu);

	GetConfig();
	return 0;
}

