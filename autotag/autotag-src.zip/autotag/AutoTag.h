#ifdef AUTOTAG_EXPORTS
#define AUTOTAG_API __declspec(dllexport)
#else
#define AUTOTAG_API __declspec(dllimport)
#endif

extern "C"{
	AUTOTAG_API DWORD EE_PluginInit(EE_Context* pContext);
}
