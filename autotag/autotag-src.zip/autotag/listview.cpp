#include "stdafx.h"
#include "listview.h"

int InsertItem(HWND hWnd, UINT nMask, int nItem, LPCTSTR lpszItem, UINT nState, UINT nStateMask, int nImage, LPARAM lParam)
{
	LVITEM item = { 0 };
	item.mask = nMask;
	item.iItem = nItem;
	item.iSubItem = 0;
	item.pszText = (LPTSTR)lpszItem;
	item.state = nState;
	item.stateMask = nStateMask;
	item.iImage = nImage;
	item.lParam = lParam;
	return (int)::SendMessage(hWnd, LVM_INSERTITEM, 0, (LPARAM)&item);
}

int InsertItem(HWND hWnd, int nItem, LPCTSTR lpszItem)
{
	return InsertItem(hWnd, LVIF_TEXT, nItem, lpszItem, 0, 0, 0, 0);
}

BOOL SetItem(HWND hWnd, int nItem, int nSubItem, UINT nMask, LPCTSTR lpszItem,
			 int nImage, UINT nState, UINT nStateMask, LPARAM lParam)
{
	LVITEM lvi = { 0 };
	lvi.mask = nMask;
	lvi.iItem = nItem;
	lvi.iSubItem = nSubItem;
	lvi.stateMask = nStateMask;
	lvi.state = nState;
	lvi.pszText = (LPTSTR) lpszItem;
	lvi.iImage = nImage;
	lvi.lParam = lParam;
	return (BOOL)::SendMessage(hWnd, LVM_SETITEM, 0, (LPARAM)&lvi);
}

BOOL SetItemText(HWND hWnd, int nItem, int nSubItem, LPCTSTR lpszText)
{
	return SetItem(hWnd, nItem, nSubItem, LVIF_TEXT, lpszText, 0, 0, 0, 0);
}

