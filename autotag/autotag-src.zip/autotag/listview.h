#pragma once

int InsertItem(HWND hWnd, UINT nMask, int nItem, LPCTSTR lpszItem, UINT nState, UINT nStateMask, int nImage, LPARAM lParam);
int InsertItem(HWND hWnd, int nItem, LPCTSTR lpszItem);
BOOL SetItem(HWND hWnd, int nItem, int nSubItem, UINT nMask, LPCTSTR lpszItem,
			 int nImage, UINT nState, UINT nStateMask, LPARAM lParam);
BOOL SetItemText(HWND hWnd, int nItem, int nSubItem, LPCTSTR lpszText);
