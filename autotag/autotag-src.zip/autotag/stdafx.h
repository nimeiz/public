#pragma once
#include "targetver.h"
#define WIN32_LEAN_AND_MEAN

#include <windows.h>

#include <tchar.h>
#include <CommCtrl.h>
#include <strsafe.h>
#include <stdlib.h>
#include <shlwapi.h>
#pragma comment(lib, "Shlwapi.lib")


#include "eesdk.h"
