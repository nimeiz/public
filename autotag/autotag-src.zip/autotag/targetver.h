#pragma once

#define WINVER			0x0500
#define _WIN32_WINNT	0x0501
#define _WIN32_WINDOWS	0x0410
#define _WIN32_IE		0x0501
